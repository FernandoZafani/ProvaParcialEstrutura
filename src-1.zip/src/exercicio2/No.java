package exercicio2;

public class No {
	Motorista motorista;
	No dir;
	No esq;
	
	public No(Motorista motorista) {
		this.motorista = motorista;
	}
}
